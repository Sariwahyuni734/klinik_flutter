package com.example.aplikasi_flutter_pertamaku

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
