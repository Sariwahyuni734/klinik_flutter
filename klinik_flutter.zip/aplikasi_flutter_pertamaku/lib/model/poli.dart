// poli.dart
class Poli {
  final String namaPoli;

  Poli({required this.namaPoli});
}
